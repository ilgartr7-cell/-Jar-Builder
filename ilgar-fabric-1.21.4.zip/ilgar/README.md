# ILGAR

Client-side Fabric utility client for **Minecraft Java 1.21.4**, aimed at anarchy servers.

* Fabric Loader 0.16.x, Fabric API, Yarn mappings, Loom 1.9, Java 21
* Open the ClickGUI with **Right Shift**, with the **ILGAR button on the pause menu** (touch), or with the chat command `.gui`
* Chat commands: `.gui`, `.t <module>`, `.list`, `.help`

## Building on GitHub (no PC needed)

1. Create a repository and upload the contents of this folder (keep `.github/workflows/build.yml`).
2. Open the **Actions** tab, run **Build ILGAR** (it also runs on every push).
3. When it finishes, download the `ilgar-jar` artifact and put the jar in your `mods` folder together with Fabric API.

Local build: `gradle build` (or `./gradlew build`, which downloads the wrapper jar on first run). Output: `build/libs/ilgar-1.0.0.jar`.
