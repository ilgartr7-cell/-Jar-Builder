package ilgar.module;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    public enum Category {
        COMBAT("Combat"), MOVEMENT("Movement"), PLAYER("Player"), RENDER("Render");

        private final String label;

        Category(String label) { this.label = label; }

        public String label() { return label; }
    }

    private final String name;
    private final Category category;
    private final List<NumberSetting> settings = new ArrayList<>();
    private boolean enabled;
    private boolean expanded;

    protected Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    protected <T extends NumberSetting> T add(T setting) {
        settings.add(setting);
        return setting;
    }

    public String getName() { return name; }
    public Category getCategory() { return category; }
    public List<NumberSetting> getSettings() { return settings; }
    public boolean isEnabled() { return enabled; }
    public boolean isExpanded() { return expanded; }
    public void setExpanded(boolean expanded) { this.expanded = expanded; }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        try {
            if (value) onEnable(); else onDisable();
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick() {}
    public void onRender(WorldRenderContext ctx) {}
}
