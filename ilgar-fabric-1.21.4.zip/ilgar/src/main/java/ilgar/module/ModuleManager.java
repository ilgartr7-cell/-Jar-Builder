package ilgar.module;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();

    private ModuleManager() {}

    public static void init() {
        MODULES.clear();
        MODULES.addAll(Modules.createAll());
    }

    public static List<Module> all() { return MODULES; }

    public static List<Module> byCategory(Module.Category category) {
        List<Module> list = new ArrayList<>();
        for (Module m : MODULES) if (m.getCategory() == category) list.add(m);
        return list;
    }

    public static Module byName(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        for (Module m : MODULES) if (m.getName().toLowerCase(Locale.ROOT).equals(n)) return m;
        return null;
    }

    public static void tick() {
        for (Module m : MODULES) {
            if (!m.isEnabled()) continue;
            try {
                m.onTick();
            } catch (Throwable t) {
                t.printStackTrace();
                m.setEnabled(false);
            }
        }
    }

    public static void render(WorldRenderContext ctx) {
        for (Module m : MODULES) {
            if (!m.isEnabled()) continue;
            try {
                m.onRender(ctx);
            } catch (Throwable t) {
                t.printStackTrace();
                m.setEnabled(false);
            }
        }
    }
}
