package ilgar.module;

import java.util.Locale;

public class NumberSetting {
    private final String name;
    private final double min;
    private final double max;
    private final double step;
    private double value;

    public NumberSetting(String name, double def, double min, double max, double step) {
        this.name = name;
        this.min = min;
        this.max = max;
        this.step = step;
        this.value = clamp(def);
    }

    private double clamp(double v) {
        v = Math.round(v / step) * step;
        v = Math.round(v * 1000.0) / 1000.0;
        return Math.max(min, Math.min(max, v));
    }

    public String getName() { return name; }
    public double getValue() { return value; }
    public int intValue() { return (int) Math.round(value); }
    public float floatValue() { return (float) value; }
    public boolean isOn() { return value >= 0.5; }
    public boolean isToggle() { return min == 0 && max == 1 && step == 1; }

    public void setValue(double v) { value = clamp(v); }
    public void increase() { value = clamp(value + step); }
    public void decrease() { value = clamp(value - step); }
    public void flip() { value = isOn() ? 0 : 1; }

    public String display() {
        if (isToggle()) return isOn() ? "On" : "Off";
        if (step >= 1) return Integer.toString(intValue());
        return String.format(Locale.ROOT, "%.2f", value);
    }
}
