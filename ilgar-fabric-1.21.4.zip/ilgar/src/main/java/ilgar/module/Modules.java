package ilgar.module;

import ilgar.util.RenderUtil;
import ilgar.util.RenderUtil.Boxed;
import ilgar.util.Util;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FallingBlock;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Every ILGAR module lives here as a nested class.
 * Hotbar slots are 0-8, PlayerInventory indices 0-35.
 */
public final class Modules {
    private Modules() {}

    // ---- instances (static so modules and mixins can reference each other) ----
    public static final MaceKill MACE_KILL = new MaceKill();
    public static final MaceDamage MACE_DAMAGE = new MaceDamage();
    public static final KillAura KILL_AURA = new KillAura();
    public static final Criticals CRITICALS = new Criticals();
    public static final AutoSword AUTO_SWORD = new AutoSword();
    public static final AutoTotem AUTO_TOTEM = new AutoTotem();
    public static final AutoArmor AUTO_ARMOR = new AutoArmor();
    public static final Velocity VELOCITY = new Velocity();
    public static final CrystalAura CRYSTAL_AURA = new CrystalAura();

    public static final Fly FLY = new Fly();
    public static final ElytraFly ELYTRA_FLY = new ElytraFly();
    public static final Speed SPEED = new Speed();
    public static final Sprint SPRINT = new Sprint();
    public static final Step STEP = new Step();
    public static final Spider SPIDER = new Spider();
    public static final Jesus JESUS = new Jesus();
    public static final Scaffold SCAFFOLD = new Scaffold();
    public static final NoFall NO_FALL = new NoFall();

    public static final AutoEat AUTO_EAT = new AutoEat();
    public static final Nuker NUKER = new Nuker();
    public static final Reach REACH = new Reach();

    public static final Fullbright FULLBRIGHT = new Fullbright();
    public static final ESP ESP = new ESP();
    public static final XRay XRAY = new XRay();
    public static final Tracers TRACERS = new Tracers();

    public static List<Module> createAll() {
        return List.<Module>of(
                MACE_KILL, MACE_DAMAGE, KILL_AURA, CRITICALS, AUTO_SWORD, AUTO_TOTEM, AUTO_ARMOR, VELOCITY, CRYSTAL_AURA,
                FLY, ELYTRA_FLY, SPEED, SPRINT, STEP, SPIDER, JESUS, SCAFFOLD, NO_FALL,
                AUTO_EAT, NUKER, REACH,
                FULLBRIGHT, ESP, XRAY, TRACERS);
    }

    // =====================================================================
    //  Attack pipeline: AutoSword -> Criticals -> MaceKill / MaceDamage
    //  Called from AttackEntityCallback, i.e. BEFORE the attack packet is sent.
    // =====================================================================
    public static void preAttack(Entity target) {
        if (!Util.inGame() || !(target instanceof LivingEntity)) return;

        if (AUTO_SWORD.isEnabled()) AUTO_SWORD.swapToBest();

        boolean mace = false;
        if (MACE_KILL.isEnabled()) mace = MACE_KILL.run();          // MaceKill wins if both are on
        else if (MACE_DAMAGE.isEnabled()) mace = MACE_DAMAGE.run();

        // Criticals would reset the fake fall distance, so it only runs when no mace attack happened.
        if (!mace && CRITICALS.isEnabled()) CRITICALS.doCrit();
    }

    /** Fake movement packets: climb in steps of at most 8 blocks, then come back to the same spot. */
    static void fakeFall(double wantedHeight) {
        ClientPlayerEntity p = mc().player;
        if (p == null || p.hasVehicle()) return;
        int free = freeHeight(p, wantedHeight);
        if (free < 2) return; // smash attack needs more than 1.5 blocks of fall distance

        double x = p.getX(), y = p.getY(), z = p.getZ();
        boolean hc = p.horizontalCollision;
        double cur = 0;
        while (cur < free) {
            cur = Math.min(free, cur + 8.0);
            Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + cur, z, false, hc));
        }
        while (cur > 0) {
            cur = Math.max(0, cur - 8.0);
            Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + cur, z, false, hc));
        }
    }

    /** How many blocks straight up the player's hitbox fits without touching anything. */
    static int freeHeight(ClientPlayerEntity p, double wanted) {
        var world = mc().world;
        Box box = p.getBoundingBox();
        int max = (int) Math.min(wanted, world.getTopYInclusive() - p.getY() - 2);
        int k = 0;
        while (k < max && world.isSpaceEmpty(p, box.offset(0, k + 1, 0))) k++;
        return k;
    }

    private static net.minecraft.client.MinecraftClient mc() {
        return net.minecraft.client.MinecraftClient.getInstance();
    }

    // =====================================================================
    //  COMBAT
    // =====================================================================
    public abstract static class MaceBase extends Module {
        final NumberSetting autoSwap = add(new NumberSetting("AutoSwap", 1, 0, 1, 1));

        MaceBase(String name) { super(name, Category.COMBAT); }

        abstract double height();

        /** @return true if a mace is in hand (so the attack is a mace attack). */
        boolean run() {
            ClientPlayerEntity p = mc.player;
            if (autoSwap.isOn()) {
                int slot = Util.findHotbar(s -> s.isOf(Items.MACE));
                if (slot >= 0) Util.selectSlot(slot);
            }
            if (!p.getMainHandStack().isOf(Items.MACE)) return false;
            fakeFall(height());
            return true;
        }
    }

    public static class MaceKill extends MaceBase {
        final NumberSetting height = add(new NumberSetting("Height", 100, 10, 300, 10));

        MaceKill() { super("MaceKill"); }

        @Override double height() { return height.getValue(); }
    }

    public static class MaceDamage extends MaceBase {
        final NumberSetting height = add(new NumberSetting("Height", 15, 2, 100, 1));

        MaceDamage() { super("MaceDamage"); }

        @Override double height() { return height.getValue(); }
    }

    public static class KillAura extends Module {
        final NumberSetting range = add(new NumberSetting("Range", 4.2, 2.0, 6.0, 0.1));
        final NumberSetting cooldown = add(new NumberSetting("Cooldown", 0.9, 0.0, 1.0, 0.1));
        final NumberSetting rotate = add(new NumberSetting("Rotate", 1, 0, 1, 1));

        KillAura() { super("KillAura", Category.COMBAT); }

        @Override
        public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
            if (p.getAttackCooldownProgress(0.5f) < cooldown.floatValue()) return;

            Vec3d eye = p.getEyePos();
            PlayerEntity best = null;
            double bestDist = Double.MAX_VALUE;
            for (PlayerEntity t : mc.world.getPlayers()) {
                if (t == p || !t.isAlive() || t.isSpectator()) continue;
                double d = eye.distanceTo(Util.closestPoint(t.getBoundingBox(), eye));
                if (d <= range.getValue() && d < bestDist) {
                    bestDist = d;
                    best = t;
                }
            }
            if (best == null) return;

            if (rotate.isOn()) {
                // silent rotation: only the server sees it, the camera does not move
                float[] r = Util.rotationsTo(eye, best.getBoundingBox().getCenter());
                Util.send(new PlayerMoveC2SPacket.LookAndOnGround(r[0], r[1], p.isOnGround(), p.horizontalCollision));
            }
            mc.interactionManager.attackEntity(p, best); // goes through AttackEntityCallback -> preAttack
            p.swingHand(Hand.MAIN_HAND);
        }
    }

    public static class Criticals extends Module {
        Criticals() { super("Criticals", Category.COMBAT); }

        void doCrit() {
            ClientPlayerEntity p = mc.player;
            if (!p.isOnGround() || p.isTouchingWater() || p.isClimbing() || p.hasVehicle()) return;
            double x = p.getX(), y = p.getY(), z = p.getZ();
            boolean hc = p.horizontalCollision;
            Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + 0.0625, z, false, hc));
            Util.send(new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false, hc));
        }
    }

    public static class AutoSword extends Module {
        AutoSword() { super("AutoSword", Category.COMBAT); }

        static int rank(ItemStack s) {
            String id = Registries.ITEM.getId(s.getItem()).getPath();
            if (!id.endsWith("_sword")) return 0;
            if (id.startsWith("netherite")) return 6;
            if (id.startsWith("diamond")) return 5;
            if (id.startsWith("iron")) return 4;
            if (id.startsWith("stone")) return 3;
            if (id.startsWith("golden")) return 2;
            return 1;
        }

        void swapToBest() {
            ClientPlayerEntity p = mc.player;
            int best = -1, bestRank = rank(p.getMainHandStack());
            for (int i = 0; i < 9; i++) {
                int r = rank(p.getInventory().getStack(i));
                if (r > bestRank) {
                    bestRank = r;
                    best = i;
                }
            }
            if (best >= 0) Util.selectSlot(best);
        }
    }

    /**
     * Mode 1: always keep a totem in the offhand.
     * Mode 2: only when health is at or below the threshold.
     * Mode 3: like 2, also when an end crystal is close or a long fall is happening.
     * Mode 4: like 1, plus keeps a spare totem in the last hotbar slot.
     */
    public static class AutoTotem extends Module {
        final NumberSetting mode = add(new NumberSetting("Mode", 1, 1, 4, 1));
        final NumberSetting health = add(new NumberSetting("Health", 12, 2, 20, 1));
        private int delay;

        AutoTotem() { super("AutoTotem", Category.COMBAT); }

        @Override
        public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p == null || !Util.invReady()) return;
            if (delay > 0) {
                delay--;
                return;
            }
            double hp = p.getHealth() + p.getAbsorptionAmount();
            boolean need = switch (mode.intValue()) {
                case 2 -> hp <= health.getValue();
                case 3 -> hp <= health.getValue() || crystalNear(p) || p.fallDistance > 12;
                default -> true;
            };

            if (need && !p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
                int slot = findTotem(p, 0);
                if (slot >= 0) {
                    Util.click(Util.containerSlot(slot), 40, SlotActionType.SWAP); // swap with offhand
                    delay = 2;
                    return;
                }
            }

            if (mode.intValue() == 4 && !p.getInventory().getStack(8).isOf(Items.TOTEM_OF_UNDYING)) {
                int slot = findTotem(p, 9);
                if (slot >= 0) {
                    Util.click(Util.containerSlot(slot), 8, SlotActionType.SWAP); // swap with last hotbar slot
                    delay = 2;
                }
            }
        }

        private static int findTotem(ClientPlayerEntity p, int from) {
            for (int i = from; i < 36; i++) {
                if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) return i;
            }
            return -1;
        }

        private static boolean crystalNear(ClientPlayerEntity p) {
            return !mc.world.getEntitiesByClass(EndCrystalEntity.class, p.getBoundingBox().expand(12), e -> true).isEmpty();
        }
    }

    public static class AutoArmor extends Module {
        private static final String[] TYPES = {"_helmet", "_chestplate", "_leggings", "_boots"};
        private int delay;

        AutoArmor() { super("AutoArmor", Category.COMBAT); }

        static int rank(ItemStack s, String suffix) {
            String id = Registries.ITEM.getId(s.getItem()).getPath();
            if (!id.endsWith(suffix)) return -1;
            if (id.startsWith("netherite")) return 6;
            if (id.startsWith("diamond")) return 5;
            if (id.startsWith("iron")) return 4;
            if (id.startsWith("chainmail")) return 3;
            if (id.startsWith("golden") || id.startsWith("turtle")) return 2;
            return 1;
        }

        @Override
        public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p == null || !Util.invReady()) return;
            if (delay > 0) {
                delay--;
                return;
            }
            for (int t = 0; t < 4; t++) {
                int armorSlot = 5 + t; // container slots 5-8 = head, chest, legs, feet
                ItemStack cur = p.playerScreenHandler.getSlot(armorSlot).getStack();
                if (t == 1 && cur.isOf(Items.ELYTRA)) continue; // keep elytra
                int curRank = Math.max(0, rank(cur, TYPES[t]));
                int bestInv = -1, bestRank = curRank;
                for (int i = 0; i < 36; i++) {
                    int r = rank(p.getInventory().getStack(i), TYPES[t]);
                    if (r > bestRank) {
                        bestRank = r;
                        bestInv = i;
                    }
                }
                if (bestInv < 0) continue;
                if (!cur.isEmpty()) {
                    Util.click(armorSlot, 0, SlotActionType.QUICK_MOVE); // take the old piece off first
                } else {
                    Util.click(Util.containerSlot(bestInv), 0, SlotActionType.QUICK_MOVE); // equips the new piece
                }
                delay = 2;
                return;
            }
        }
    }

    /** Knockback is cancelled in ClientPlayNetworkHandlerMixin when this module is on. */
    public static class Velocity extends Module {
        Velocity() { super("Velocity", Category.COMBAT); }
    }

    public static class CrystalAura extends Module {
        final NumberSetting range = add(new NumberSetting("Range", 5.0, 3.0, 6.0, 0.5));
        final NumberSetting delay = add(new NumberSetting("Delay", 2, 0, 10, 1));
        private int cd;

        CrystalAura() { super("CrystalAura", Category.COMBAT); }

        @Override
        public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
            if (cd > 0) {
                cd--;
                return;
            }
            PlayerEntity target = null;
            double td = 100;
            for (PlayerEntity t : mc.world.getPlayers()) {
                if (t == p || !t.isAlive() || t.isSpectator()) continue;
                double d = p.squaredDistanceTo(t);
                if (d < td) {
                    td = d;
                    target = t;
                }
            }
            if (target == null) return;

            // 1) break crystals near the target
            EndCrystalEntity crystal = null;
            double cdist = Double.MAX_VALUE;
            for (EndCrystalEntity c : mc.world.getEntitiesByClass(EndCrystalEntity.class, p.getBoundingBox().expand(range.getValue()), e -> true)) {
                if (p.distanceTo(c) > range.getValue() || c.squaredDistanceTo(target) > 36) continue;
                if (p.distanceTo(c) < 3 && p.getHealth() < 8) continue; // do not pop ourselves at low health
                double d = c.squaredDistanceTo(target);
                if (d < cdist) {
                    cdist = d;
                    crystal = c;
                }
            }
            if (crystal != null) {
                mc.interactionManager.attackEntity(p, crystal);
                p.swingHand(Hand.MAIN_HAND);
                cd = delay.intValue();
                return;
            }

            // 2) place a crystal on obsidian/bedrock next to the target
            Hand hand;
            if (p.getOffHandStack().isOf(Items.END_CRYSTAL)) {
                hand = Hand.OFF_HAND;
            } else {
                int slot = Util.findHotbar(s -> s.isOf(Items.END_CRYSTAL));
                if (slot < 0) return;
                Util.selectSlot(slot);
                hand = Hand.MAIN_HAND;
            }

            BlockPos tp = target.getBlockPos();
            BlockPos best = null;
            double bestDist = Double.MAX_VALUE;
            Vec3d eye = p.getEyePos();
            for (int dx = -4; dx <= 4; dx++) {
                for (int dy = -3; dy <= 2; dy++) {
                    for (int dz = -4; dz <= 4; dz++) {
                        BlockPos base = tp.add(dx, dy, dz);
                        Block b = mc.world.getBlockState(base).getBlock();
                        if (b != Blocks.OBSIDIAN && b != Blocks.BEDROCK) continue;
                        if (!mc.world.getBlockState(base.up()).isAir() || !mc.world.getBlockState(base.up(2)).isAir()) continue;
                        Vec3d top = Vec3d.ofCenter(base).add(0, 0.5, 0);
                        double mine = eye.distanceTo(top);
                        if (mine > range.getValue() || mine < 2.5) continue;
                        Box area = new Box(base.getX(), base.getY() + 1, base.getZ(), base.getX() + 1, base.getY() + 3, base.getZ() + 1);
                        if (!mc.world.getOtherEntities(null, area, e -> true).isEmpty()) continue;
                        double d = top.squaredDistanceTo(target.getPos());
                        if (d < bestDist) {
                            bestDist = d;
                            best = base;
                        }
                    }
                }
            }
            if (best == null) return;
            BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(best).add(0, 0.5, 0), Direction.UP, best, false);
            mc.interactionManager.interactBlock(p, hand, hit);
            p.swingHand(hand);
            cd = delay.intValue();
        }
    }

    // =====================================================================
    //  MOVEMENT
    // =====================================================================
    public static class Fly extends Module {
        final NumberSetting speed = add(new NumberSetting("Speed", 1.0, 0.1, 5.0, 0.1));
        private int ticks;

        Fly() { super("Fly", Category.MOVEMENT); }

        @Override
        protected void onEnable() { ticks = 0; }

        @Override
        public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p == null || p.hasVehicle()) return;
            double s = speed.getValue();
            Vec3d h = Util.horizontalInput(s);
            double vy = 0;
            if (mc.options.jumpKey.isPressed()) vy += s;
            if (mc.options.sneakKey.isPressed()) vy -= s;
            // anti-kick: a small drop every 25 ticks resets the server's "floating" counter
            if (++ticks % 25 == 0 && vy == 0) vy = -0.06;
            p.setVelocity(h.x, vy, h.z);
        }
    }

    public static class ElytraFly extends Module {
        final NumberSetting speed = add(new NumberSetting("Speed", 1.0, 0.1, 3.0, 0.1));

        ElytraFly() { super("ElytraFly", Category.MOVEMENT); }

        @Override
        public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p == null || !Util.gliding(p)) return;
            double s = speed.getValue();
            if (mc.options.forwardKey.isPressed()) {
                p.setVelocity(p.getRotationVec(1.0f).multiply(s));
            } else {
                double vy = 0;
                if (mc.options.jumpKey.isPressed()) vy = s * 0.5;
                if (mc.options.sneakKey.isPressed()) vy = -s * 0.5;
                p.setVelocity(0, vy, 0);
            }
        }
    }

    public static class Speed extends Module {
        final NumberSetting speed = add(new NumberSetting("Speed", 1.5, 1.0, 5.0, 0.1));

        Speed() { super("Speed", Category.MOVEMENT); }

        @Override
        public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p == null || p.hasVehicle() || p.isTouchingWater() || p.isClimbing() || Util.gliding(p)) return;
            Vec3d m = Util.horizontalInput(0.2873 * speed.getValue());
            if (m == Vec3d.ZERO) return;
            p.setVelocity(m.x, p.getVelocity().y, m.z);
        }
    }

    public static class Sprint extends Module {
        Sprint() { super("Sprint", Category.MOVEMENT); }

        @Override
        public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p == null) return;
            if (mc.options.forwardKey.isPressed() && !p.isSneaking() && !p.horizontalCollision
                    && p.getHungerManager().getFoodLevel() > 6) {
                p.setSprinting(true);
            }
        }
    }

    public static class Step extends Module {
        final NumberSetting height = add(new NumberSetting("Height", 2.0, 1.0, 5.0, 0.5));
        private double original = -1;

        Step() { super("Step", Category.MOVEMENT); }

        @Override
        public void onTick() {
            EntityAttributeInstance a = Util.attribute("step_height");
            if (a == null) return;
            if (original < 0) original = a.getBaseValue();
            a.setBaseValue(height.getValue());
        }

        @Override
        protected void onDisable() {
            EntityAttributeInstance a = Util.attribute("step_height");
            if (a != null && original >= 0) a.setBaseValue(original);
            original = -1;
        }
    }

    public static class Spider extends Module {
        Spider() { super("Spider", Category.MOVEMENT); }

        @Override
        public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p == null || p.isSneaking()) return;
            if (p.horizontalCollision) {
                Vec3d v = p.getVelocity();
                p.setVelocity(v.x, 0.2, v.z);
            }
        }
    }

    public static class Jesus extends Module {
        private int ticks;

        Jesus() { super("Jesus", Category.MOVEMENT); }

        @Override
        public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p == null || mc.world == null || p.isSneaking() || mc.options.jumpKey.isPressed()) return;
            Vec3d v = p.getVelocity();
            if (p.isTouchingWater() || p.isInLava()) {
                p.setVelocity(v.x, 0.11, v.z); // float up to the surface
            } else if (overLiquid(p)) {
                // hover; a tiny dip every few ticks keeps the player "touching" the liquid and avoids the floating check
                p.setVelocity(v.x, ++ticks % 6 == 0 ? -0.04 : 0, v.z);
            }
        }

        private static boolean overLiquid(ClientPlayerEntity p) {
            BlockPos below = BlockPos.ofFloored(p.getX(), p.getY() - 0.05, p.getZ());
            BlockPos feet = BlockPos.ofFloored(p.getX(), p.getY(), p.getZ());
            return !mc.world.getFluidState(below).isEmpty() && mc.world.getFluidState(feet).isEmpty();
        }
    }

    public static class Scaffold extends Module {
        private int previousSlot = -1;

        Scaffold() { super("Scaffold", Category.MOVEMENT); }

        @Override
        protected void onEnable() {
            previousSlot = mc.player == null ? -1 : mc.player.getInventory().selectedSlot;
        }

        @Override
        protected void onDisable() {
            if (previousSlot >= 0 && Util.inGame()) Util.selectSlot(previousSlot);
            previousSlot = -1;
        }

        @Override
        public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p == null || mc.world == null || mc.currentScreen != null) return;
            BlockPos target = BlockPos.ofFloored(p.getX(), p.getY() - 1, p.getZ());
            if (!mc.world.getBlockState(target).isReplaceable()) return;
            int slot = Util.findHotbar(Scaffold::usable);
            if (slot < 0) return;
            Util.selectSlot(slot);
            Util.placeAt(target);
        }

        private static boolean usable(ItemStack s) {
            if (!(s.getItem() instanceof BlockItem bi)) return false;
            Block b = bi.getBlock();
            return b.getDefaultState().isFullCube(mc.world, BlockPos.ORIGIN)
                    && !(b instanceof FallingBlock) && !(b instanceof BlockEntityProvider) && b != Blocks.TNT;
        }
    }

    public static class NoFall extends Module {
        NoFall() { super("NoFall", Category.MOVEMENT); }

        @Override
        public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p == null || p.isOnGround() || Util.gliding(p) || p.getAbilities().allowFlying) return;
            if (maceActive(p)) return; // would wipe the server-side fall distance a mace needs
            if (p.fallDistance > 2.5) {
                Util.send(new PlayerMoveC2SPacket.OnGroundOnly(true, p.horizontalCollision));
            }
        }

        private static boolean maceActive(ClientPlayerEntity p) {
            if (p.getMainHandStack().isOf(Items.MACE)) return true;
            boolean auto = (MACE_KILL.isEnabled() && MACE_KILL.autoSwap.isOn())
                    || (MACE_DAMAGE.isEnabled() && MACE_DAMAGE.autoSwap.isOn());
            return auto && Util.findHotbar(s -> s.isOf(Items.MACE)) >= 0;
        }
    }

    // =====================================================================
    //  PLAYER
    // =====================================================================
    public static class AutoEat extends Module {
        private static final Set<String> BAD = Set.of("rotten_flesh", "spider_eye", "poisonous_potato", "pufferfish",
                "chorus_fruit", "suspicious_stew", "enchanted_golden_apple");
        final NumberSetting hunger = add(new NumberSetting("Hunger", 14, 2, 19, 1));
        private boolean eating;
        private int previousSlot = -1;

        AutoEat() { super("AutoEat", Category.PLAYER); }

        @Override
        protected void onDisable() { stop(); }

        @Override
        public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p == null) return;
            int food = p.getHungerManager().getFoodLevel();
            if (eating) {
                boolean full = food >= Math.min(20, hunger.intValue() + 4);
                if (full || mc.currentScreen != null || !isFood(p.getMainHandStack())) {
                    stop();
                } else {
                    mc.options.useKey.setPressed(true);
                }
                return;
            }
            if (food > hunger.intValue() || mc.currentScreen != null) return;
            int slot = Util.findHotbar(AutoEat::isFood);
            if (slot < 0) return;
            previousSlot = p.getInventory().selectedSlot;
            Util.selectSlot(slot);
            eating = true;
            mc.options.useKey.setPressed(true);
        }

        private void stop() {
            if (!eating) return;
            mc.options.useKey.setPressed(false);
            if (previousSlot >= 0 && Util.inGame()) Util.selectSlot(previousSlot);
            previousSlot = -1;
            eating = false;
        }

        private static boolean isFood(ItemStack s) {
            return s.contains(DataComponentTypes.FOOD) && !BAD.contains(Registries.ITEM.getId(s.getItem()).getPath());
        }
    }

    public static class Nuker extends Module {
        final NumberSetting range = add(new NumberSetting("Range", 4, 1, 6, 1));

        Nuker() { super("Nuker", Category.PLAYER); }

        @Override
        public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
            int r = range.intValue();
            BlockPos base = p.getBlockPos();
            Vec3d eye = p.getEyePos();
            BlockPos best = null;
            double bestDist = Double.MAX_VALUE;
            for (BlockPos pos : BlockPos.iterate(base.add(-r, -r, -r), base.add(r, r, r))) {
                BlockState st = mc.world.getBlockState(pos);
                if (st.isAir() || !st.getFluidState().isEmpty() || st.getHardness(mc.world, pos) < 0) continue;
                if (pos.getX() == base.getX() && pos.getZ() == base.getZ() && pos.getY() < p.getY()) continue; // never dig our own floor
                double d = eye.squaredDistanceTo(Vec3d.ofCenter(pos));
                if (d > r * r || d >= bestDist) continue;
                bestDist = d;
                best = pos.toImmutable();
            }
            if (best == null) return;
            mc.interactionManager.updateBlockBreakingProgress(best, Direction.UP);
            p.swingHand(Hand.MAIN_HAND);
        }
    }

    public static class Reach extends Module {
        final NumberSetting range = add(new NumberSetting("Range", 5.0, 3.0, 6.0, 0.5));
        private double origEntity = -1, origBlock = -1;

        Reach() { super("Reach", Category.PLAYER); }

        @Override
        public void onTick() {
            EntityAttributeInstance e = Util.attribute("entity_interaction_range");
            EntityAttributeInstance b = Util.attribute("block_interaction_range");
            if (e != null) {
                if (origEntity < 0) origEntity = e.getBaseValue();
                e.setBaseValue(range.getValue());
            }
            if (b != null) {
                if (origBlock < 0) origBlock = b.getBaseValue();
                b.setBaseValue(Math.max(range.getValue(), origBlock));
            }
        }

        @Override
        protected void onDisable() {
            EntityAttributeInstance e = Util.attribute("entity_interaction_range");
            EntityAttributeInstance b = Util.attribute("block_interaction_range");
            if (e != null && origEntity >= 0) e.setBaseValue(origEntity);
            if (b != null && origBlock >= 0) b.setBaseValue(origBlock);
            origEntity = -1;
            origBlock = -1;
        }
    }

    // =====================================================================
    //  RENDER
    // =====================================================================
    public static class Fullbright extends Module {
        Fullbright() { super("Fullbright", Category.RENDER); }

        @Override
        public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p == null) return;
            if (!p.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, StatusEffectInstance.INFINITE, 0, false, false, false));
            }
        }

        @Override
        protected void onDisable() {
            if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }

    public static class ESP extends Module {
        final NumberSetting players = add(new NumberSetting("Players", 1, 0, 1, 1));
        final NumberSetting mobs = add(new NumberSetting("Mobs", 0, 0, 1, 1));

        ESP() { super("ESP", Category.RENDER); }

        @Override
        public void onRender(WorldRenderContext ctx) {
            if (mc.world == null || mc.player == null) return;
            List<Boxed> list = new ArrayList<>();
            for (Entity e : mc.world.getEntities()) {
                if (e == mc.player) continue;
                if (e instanceof PlayerEntity && players.isOn()) {
                    list.add(new Boxed(e.getBoundingBox(), 0xFFFF3B3B));
                } else if (e instanceof LivingEntity && !(e instanceof PlayerEntity) && mobs.isOn()) {
                    list.add(new Boxed(e.getBoundingBox(), 0xFF3BFF6B));
                }
            }
            RenderUtil.boxes(ctx, list);
        }
    }

    /**
     * Ore / storage finder. With only one mixin allowed this is a through-walls highlighter
     * (like an "ore ESP"), not a texture-removing x-ray.
     */
    public static class XRay extends Module {
        private static final Map<Block, Integer> ORES = new HashMap<>();
        private static final Map<Block, Integer> STORAGE = new HashMap<>();

        static {
            int diamond = 0xFF33E6FF, emerald = 0xFF22FF66, gold = 0xFFFFD11A, iron = 0xFFE0B090, redstone = 0xFFFF2020,
                    lapis = 0xFF3355FF, coal = 0xFF666666, copper = 0xFFFF8844, debris = 0xFFB5651D, quartz = 0xFFF2F2F2;
            ORES.put(Blocks.DIAMOND_ORE, diamond);
            ORES.put(Blocks.DEEPSLATE_DIAMOND_ORE, diamond);
            ORES.put(Blocks.EMERALD_ORE, emerald);
            ORES.put(Blocks.DEEPSLATE_EMERALD_ORE, emerald);
            ORES.put(Blocks.GOLD_ORE, gold);
            ORES.put(Blocks.DEEPSLATE_GOLD_ORE, gold);
            ORES.put(Blocks.NETHER_GOLD_ORE, gold);
            ORES.put(Blocks.IRON_ORE, iron);
            ORES.put(Blocks.DEEPSLATE_IRON_ORE, iron);
            ORES.put(Blocks.REDSTONE_ORE, redstone);
            ORES.put(Blocks.DEEPSLATE_REDSTONE_ORE, redstone);
            ORES.put(Blocks.LAPIS_ORE, lapis);
            ORES.put(Blocks.DEEPSLATE_LAPIS_ORE, lapis);
            ORES.put(Blocks.COAL_ORE, coal);
            ORES.put(Blocks.DEEPSLATE_COAL_ORE, coal);
            ORES.put(Blocks.COPPER_ORE, copper);
            ORES.put(Blocks.DEEPSLATE_COPPER_ORE, copper);
            ORES.put(Blocks.NETHER_QUARTZ_ORE, quartz);
            ORES.put(Blocks.ANCIENT_DEBRIS, debris);

            STORAGE.put(Blocks.CHEST, 0xFFFFAA00);
            STORAGE.put(Blocks.TRAPPED_CHEST, 0xFFFF5500);
            STORAGE.put(Blocks.BARREL, 0xFFCC8833);
            STORAGE.put(Blocks.ENDER_CHEST, 0xFFAA44FF);
            STORAGE.put(Blocks.SPAWNER, 0xFFFF00AA);
        }

        private static final int SHULKER = 0xFFFF66FF;

        final NumberSetting range = add(new NumberSetting("Range", 20, 8, 48, 4));
        final NumberSetting ores = add(new NumberSetting("Ores", 1, 0, 1, 1));
        final NumberSetting storage = add(new NumberSetting("Storage", 1, 0, 1, 1));
        private List<Boxed> found = new ArrayList<>();
        private int tick;

        XRay() { super("XRay", Category.RENDER); }

        @Override
        protected void onEnable() { tick = 0; }

        @Override
        protected void onDisable() { found = new ArrayList<>(); }

        @Override
        public void onTick() {
            if (mc.world == null || mc.player == null) return;
            if (tick++ % 30 != 0) return; // rescan every 1.5 seconds
            int r = range.intValue();
            BlockPos c = mc.player.getBlockPos();
            int minY = Math.max(mc.world.getBottomY(), c.getY() - r);
            int maxY = Math.min(mc.world.getTopYInclusive(), c.getY() + r);
            List<Boxed> list = new ArrayList<>();
            BlockPos.Mutable m = new BlockPos.Mutable();
            scan:
            for (int x = c.getX() - r; x <= c.getX() + r; x++) {
                for (int z = c.getZ() - r; z <= c.getZ() + r; z++) {
                    for (int y = minY; y <= maxY; y++) {
                        m.set(x, y, z);
                        BlockState s = mc.world.getBlockState(m);
                        if (s.isAir()) continue;
                        Block b = s.getBlock();
                        Integer col = null;
                        if (ores.isOn()) col = ORES.get(b);
                        if (col == null && storage.isOn()) {
                            col = STORAGE.get(b);
                            if (col == null && b instanceof ShulkerBoxBlock) col = SHULKER;
                        }
                        if (col == null) continue;
                        list.add(new Boxed(new Box(m), col));
                        if (list.size() >= 2500) break scan;
                    }
                }
            }
            found = list;
        }

        @Override
        public void onRender(WorldRenderContext ctx) {
            RenderUtil.boxes(ctx, found);
        }
    }

    public static class Tracers extends Module {
        Tracers() { super("Tracers", Category.RENDER); }

        @Override
        public void onRender(WorldRenderContext ctx) {
            if (mc.world == null || mc.player == null) return;
            Matrix4f m = RenderUtil.matrix(ctx);
            if (m == null) return;
            Vec3d cam = ctx.camera().getPos();
            Vec3d start = Vec3d.fromPolar(ctx.camera().getPitch(), ctx.camera().getYaw()); // crosshair, camera-relative
            RenderUtil.begin();
            net.minecraft.client.render.BufferBuilder b = RenderUtil.lines();
            int count = 0;
            for (PlayerEntity t : mc.world.getPlayers()) {
                if (t == mc.player || !t.isAlive()) continue;
                Vec3d end = t.getBoundingBox().getCenter().subtract(cam);
                RenderUtil.line(b, m, (float) start.x, (float) start.y, (float) start.z,
                        (float) end.x, (float) end.y, (float) end.z, 0xFFFF3B3B);
                count++;
            }
            com.mojang.blaze3d.systems.RenderSystem.lineWidth(1.5f);
            if (count > 0) RenderUtil.draw(b);
            RenderUtil.end();
        }
    }
}
