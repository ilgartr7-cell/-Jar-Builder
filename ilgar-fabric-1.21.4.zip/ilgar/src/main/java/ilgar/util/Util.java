package ilgar.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Optional;
import java.util.function.Predicate;

public final class Util {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private Util() {}

    public static boolean inGame() {
        return mc.player != null && mc.world != null && mc.getNetworkHandler() != null;
    }

    public static void send(Packet<?> packet) {
        if (mc.getNetworkHandler() != null) mc.getNetworkHandler().sendPacket(packet);
    }

    /** Hotbar index (0-8) of the first stack matching the predicate, or -1. */
    public static int findHotbar(Predicate<ItemStack> predicate) {
        if (mc.player == null) return -1;
        for (int i = 0; i < 9; i++) {
            if (predicate.test(mc.player.getInventory().getStack(i))) return i;
        }
        return -1;
    }

    public static void selectSlot(int slot) {
        if (mc.player == null || slot < 0 || slot > 8) return;
        if (mc.player.getInventory().selectedSlot != slot) {
            mc.player.getInventory().selectedSlot = slot;
            send(new UpdateSelectedSlotC2SPacket(slot));
        }
    }

    // ---- inventory clicks (player inventory only) ----

    public static boolean invReady() {
        return mc.player != null && mc.interactionManager != null
                && mc.player.currentScreenHandler == mc.player.playerScreenHandler;
    }

    public static void click(int containerSlot, int button, SlotActionType type) {
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, containerSlot, button, type, mc.player);
    }

    /** PlayerInventory index (0-35) -> container slot id of the player screen handler. */
    public static int containerSlot(int invIndex) {
        return invIndex < 9 ? 36 + invIndex : invIndex;
    }

    // ---- math ----

    public static float[] rotationsTo(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        return new float[]{MathHelper.wrapDegrees(yaw), MathHelper.clamp(pitch, -90f, 90f)};
    }

    public static Vec3d closestPoint(Box box, Vec3d p) {
        return new Vec3d(
                MathHelper.clamp(p.x, box.minX, box.maxX),
                MathHelper.clamp(p.y, box.minY, box.maxY),
                MathHelper.clamp(p.z, box.minZ, box.maxZ));
    }

    /** Horizontal movement vector from the WASD keys, relative to the player's yaw. */
    public static Vec3d horizontalInput(double speed) {
        var o = mc.options;
        float f = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
        float s = (o.leftKey.isPressed() ? 1 : 0) - (o.rightKey.isPressed() ? 1 : 0);
        if (f == 0 && s == 0) return Vec3d.ZERO;
        double yaw = Math.toRadians(mc.player.getYaw());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        double x = -sin * f + cos * s;
        double z = cos * f + sin * s;
        double len = Math.sqrt(x * x + z * z);
        return new Vec3d(x / len * speed, 0, z / len * speed);
    }

    /** Works with both naming schemes (GLIDING / FALL_FLYING) of the pose enum. */
    public static boolean gliding(ClientPlayerEntity p) {
        String n = p.getPose().name();
        return n.equals("GLIDING") || n.equals("FALL_FLYING");
    }

    // ---- attributes (looked up by id so it works across mapping renames) ----

    public static EntityAttributeInstance attribute(String path) {
        if (mc.player == null) return null;
        for (String id : new String[]{path, "generic." + path}) {
            Optional<RegistryEntry.Reference<EntityAttribute>> entry =
                    Registries.ATTRIBUTE.getEntry(Identifier.ofVanilla(id));
            if (entry.isPresent()) return mc.player.getAttributeInstance(entry.get());
        }
        return null;
    }

    // ---- block placing ----

    /** Places the currently held block at pos by clicking a neighbouring block. */
    public static boolean placeAt(BlockPos pos) {
        if (mc.world == null || mc.player == null || mc.interactionManager == null) return false;
        for (Direction d : Direction.values()) {
            BlockPos n = pos.offset(d);
            if (mc.world.getBlockState(n).isReplaceable()) continue;
            Direction side = d.getOpposite();
            Vec3d hit = Vec3d.ofCenter(n).add(side.getOffsetX() * 0.5, side.getOffsetY() * 0.5, side.getOffsetZ() * 0.5);
            ActionResult r = mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(hit, side, n, false));
            if (r.isAccepted()) {
                mc.player.swingHand(Hand.MAIN_HAND);
                return true;
            }
        }
        return false;
    }
}
