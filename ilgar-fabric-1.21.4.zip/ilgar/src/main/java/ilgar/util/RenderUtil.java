package ilgar.util;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.ShaderProgramKeys;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.List;

/** Minimal through-walls drawing helpers (no mixins needed). */
public final class RenderUtil {
    public record Boxed(Box box, int argb) {}

    private RenderUtil() {}

    public static void begin() {
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
    }

    public static void end() {
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.enableDepthTest();
    }

    public static BufferBuilder quads() {
        return Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
    }

    public static BufferBuilder lines() {
        return Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
    }

    public static void draw(BufferBuilder builder) {
        BuiltBuffer built = builder.endNullable();
        if (built != null) BufferRenderer.drawWithGlobalProgram(built);
    }

    public static Matrix4f matrix(WorldRenderContext ctx) {
        MatrixStack ms = ctx.matrixStack();
        return ms == null ? null : ms.peek().getPositionMatrix();
    }

    /** Draws filled + outlined boxes through walls. Fill and outline use separate buffers, one after another. */
    public static void boxes(WorldRenderContext ctx, List<Boxed> list) {
        if (list.isEmpty()) return;
        Matrix4f m = matrix(ctx);
        if (m == null) return;
        Vec3d cam = ctx.camera().getPos();
        begin();
        BufferBuilder fill = quads();
        for (Boxed b : list) fillBox(fill, m, cam, b.box(), (b.argb() & 0x00FFFFFF) | 0x38000000);
        draw(fill);
        RenderSystem.lineWidth(1.6f);
        BufferBuilder lines = lines();
        for (Boxed b : list) outlineBox(lines, m, cam, b.box(), b.argb());
        draw(lines);
        end();
    }

    private static void v(BufferBuilder b, Matrix4f m, float x, float y, float z, int c) {
        b.vertex(m, x, y, z).color((c >> 16) & 255, (c >> 8) & 255, c & 255, (c >>> 24) & 255);
    }

    public static void fillBox(BufferBuilder b, Matrix4f m, Vec3d cam, Box box, int c) {
        float x1 = (float) (box.minX - cam.x), y1 = (float) (box.minY - cam.y), z1 = (float) (box.minZ - cam.z);
        float x2 = (float) (box.maxX - cam.x), y2 = (float) (box.maxY - cam.y), z2 = (float) (box.maxZ - cam.z);
        // bottom
        v(b, m, x1, y1, z1, c); v(b, m, x2, y1, z1, c); v(b, m, x2, y1, z2, c); v(b, m, x1, y1, z2, c);
        // top
        v(b, m, x1, y2, z1, c); v(b, m, x1, y2, z2, c); v(b, m, x2, y2, z2, c); v(b, m, x2, y2, z1, c);
        // north
        v(b, m, x1, y1, z1, c); v(b, m, x1, y2, z1, c); v(b, m, x2, y2, z1, c); v(b, m, x2, y1, z1, c);
        // south
        v(b, m, x1, y1, z2, c); v(b, m, x2, y1, z2, c); v(b, m, x2, y2, z2, c); v(b, m, x1, y2, z2, c);
        // west
        v(b, m, x1, y1, z1, c); v(b, m, x1, y1, z2, c); v(b, m, x1, y2, z2, c); v(b, m, x1, y2, z1, c);
        // east
        v(b, m, x2, y1, z1, c); v(b, m, x2, y2, z1, c); v(b, m, x2, y2, z2, c); v(b, m, x2, y1, z2, c);
    }

    public static void outlineBox(BufferBuilder b, Matrix4f m, Vec3d cam, Box box, int c) {
        float x1 = (float) (box.minX - cam.x), y1 = (float) (box.minY - cam.y), z1 = (float) (box.minZ - cam.z);
        float x2 = (float) (box.maxX - cam.x), y2 = (float) (box.maxY - cam.y), z2 = (float) (box.maxZ - cam.z);
        line(b, m, x1, y1, z1, x2, y1, z1, c); line(b, m, x2, y1, z1, x2, y1, z2, c);
        line(b, m, x2, y1, z2, x1, y1, z2, c); line(b, m, x1, y1, z2, x1, y1, z1, c);
        line(b, m, x1, y2, z1, x2, y2, z1, c); line(b, m, x2, y2, z1, x2, y2, z2, c);
        line(b, m, x2, y2, z2, x1, y2, z2, c); line(b, m, x1, y2, z2, x1, y2, z1, c);
        line(b, m, x1, y1, z1, x1, y2, z1, c); line(b, m, x2, y1, z1, x2, y2, z1, c);
        line(b, m, x2, y1, z2, x2, y2, z2, c); line(b, m, x1, y1, z2, x1, y2, z2, c);
    }

    public static void line(BufferBuilder b, Matrix4f m, float x1, float y1, float z1, float x2, float y2, float z2, int c) {
        v(b, m, x1, y1, z1, c);
        v(b, m, x2, y2, z2, c);
    }
}
