package ilgar;

import ilgar.gui.ClickGuiScreen;
import ilgar.gui.Hud;
import ilgar.module.Module;
import ilgar.module.ModuleManager;
import ilgar.module.Modules;
import ilgar.util.Util;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

public class IlgarClient implements ClientModInitializer {
    public static final String NAME = "ILGAR";

    private static KeyBinding guiKey;
    private static boolean openGui;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();

        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.ilgar.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.ilgar"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (guiKey.wasPressed()) {
                if (client.currentScreen == null) openGui = true;
            }
            if (openGui && client.currentScreen == null) {
                openGui = false;
                client.setScreen(new ClickGuiScreen());
            }
            if (Util.inGame()) ModuleManager.tick();
        });

        // Hits go through AttackEntityCallback so fake packets are sent BEFORE the attack packet.
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.isClient && player == MinecraftClient.getInstance().player) Modules.preAttack(entity);
            return ActionResult.PASS;
        });

        WorldRenderEvents.LAST.register(ModuleManager::render);
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> Hud.render(ctx));

        // Touch-friendly ways to open the GUI: a button on the pause menu and the .gui chat command.
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof GameMenuScreen) {
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal(NAME),
                        b -> client.setScreen(new ClickGuiScreen())).dimensions(4, 4, 60, 20).build());
            }
        });

        ClientSendMessageEvents.ALLOW_CHAT.register(IlgarClient::handleChat);
    }

    /** Chat commands: .gui  .t <module>  .list  .help  (anything else is sent as normal chat). */
    private static boolean handleChat(String message) {
        if (!message.startsWith(".")) return true;
        String[] a = message.substring(1).trim().split("\\s+");
        String cmd = a[0].toLowerCase();
        switch (cmd) {
            case "gui" -> openGui = true;
            case "t", "toggle" -> {
                Module m = a.length > 1 ? ModuleManager.byName(a[1]) : null;
                if (m == null) {
                    info("Unknown module. Use .list");
                } else {
                    m.toggle();
                    info(m.getName() + (m.isEnabled() ? " ON" : " OFF"));
                }
            }
            case "list" -> {
                StringBuilder sb = new StringBuilder();
                for (Module m : ModuleManager.all()) {
                    if (sb.length() > 0) sb.append(", ");
                    sb.append(m.getName());
                }
                info(sb.toString());
            }
            case "help" -> info(".gui | .t <module> | .list");
            default -> {
                return true;
            }
        }
        return false;
    }

    private static void info(String text) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.sendMessage(Text.literal("[" + NAME + "] " + text), false);
    }
}
