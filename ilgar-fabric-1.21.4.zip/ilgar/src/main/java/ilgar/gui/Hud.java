package ilgar.gui;

import ilgar.IlgarClient;
import ilgar.module.Module;
import ilgar.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;

public final class Hud {
    private Hud() {}

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;

        ctx.drawTextWithShadow(tr, IlgarClient.NAME, 4, 4, 0xFF8E5CFF);

        List<Module> active = new ArrayList<>();
        for (Module m : ModuleManager.all()) if (m.isEnabled()) active.add(m);
        active.sort((a, b) -> tr.getWidth(b.getName()) - tr.getWidth(a.getName()));

        int width = ctx.getScaledWindowWidth();
        float phase = (System.currentTimeMillis() % 4000L) / 4000f;
        int y = 4;
        for (int i = 0; i < active.size(); i++) {
            String name = active.get(i).getName();
            int color = 0xFF000000 | MathHelper.hsvToRgb((phase + i * 0.045f) % 1f, 0.55f, 1f);
            ctx.drawTextWithShadow(tr, name, width - tr.getWidth(name) - 4, y, color);
            y += 10;
        }
    }
}
