package ilgar.gui;

import ilgar.module.Module;
import ilgar.module.ModuleManager;
import ilgar.module.NumberSetting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Simple ClickGUI.
 * Module: left click = on/off, right click (or the +/- button) = show settings.
 * Setting: click "<" or ">" to change the value; On/Off settings flip when clicked anywhere on the row.
 */
public class ClickGuiScreen extends Screen {
    private enum Kind { HEADER, MODULE, SETTING }

    private static final class Row {
        Kind kind;
        int x, y, w, h;
        Module module;
        NumberSetting setting;
        String label = "";
        String value = "";
        int lx0, gx0, vx;
    }

    private static final int HEADER_H = 16;
    private static final int ROW_H = 14;
    private static final int SETTING_H = 13;

    public ClickGuiScreen() {
        super(Text.literal("ILGAR"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private List<Row> buildRows() {
        List<Row> rows = new ArrayList<>();
        Module.Category[] cats = Module.Category.values();
        int gap = 4;
        int pw = Math.max(84, Math.min(118, (width - gap) / cats.length - gap));
        int x = Math.max(gap, (width - ((pw + gap) * cats.length - gap)) / 2);

        for (Module.Category cat : cats) {
            int y = 14;
            Row header = new Row();
            header.kind = Kind.HEADER;
            header.x = x; header.y = y; header.w = pw; header.h = HEADER_H;
            header.label = cat.label();
            rows.add(header);
            y += HEADER_H;

            for (Module m : ModuleManager.byCategory(cat)) {
                Row r = new Row();
                r.kind = Kind.MODULE;
                r.x = x; r.y = y; r.w = pw; r.h = ROW_H;
                r.module = m;
                r.label = m.getName();
                rows.add(r);
                y += ROW_H;

                if (!m.isExpanded()) continue;
                for (NumberSetting s : m.getSettings()) {
                    Row sr = new Row();
                    sr.kind = Kind.SETTING;
                    sr.x = x; sr.y = y; sr.w = pw; sr.h = SETTING_H;
                    sr.module = m;
                    sr.setting = s;
                    sr.label = s.getName();
                    sr.value = s.display();
                    int vw = textRenderer.getWidth(sr.value);
                    sr.gx0 = x + pw - 9;
                    sr.vx = sr.gx0 - 3 - vw;
                    sr.lx0 = sr.vx - 3 - 6;
                    rows.add(sr);
                    y += SETTING_H;
                }
            }
            x += pw + gap;
        }
        return rows;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x66000000);
        ctx.drawTextWithShadow(textRenderer, "ILGAR  |  L-click: on/off   R-click or +: settings   < > : value", 4, 3, 0xFFFFFFFF);

        for (Row r : buildRows()) {
            boolean hover = mouseX >= r.x && mouseX < r.x + r.w && mouseY >= r.y && mouseY < r.y + r.h;
            switch (r.kind) {
                case HEADER -> {
                    ctx.fill(r.x, r.y, r.x + r.w, r.y + r.h, 0xFF2A1F4D);
                    ctx.drawTextWithShadow(textRenderer, r.label, r.x + 4, r.y + 4, 0xFFB79CFF);
                }
                case MODULE -> {
                    boolean on = r.module.isEnabled();
                    int bg = on ? (hover ? 0xFF7351F0 : 0xFF5B3FD6) : (hover ? 0xDD2A2A3A : 0xDD15151F);
                    ctx.fill(r.x, r.y, r.x + r.w, r.y + r.h, bg);
                    String name = textRenderer.trimToWidth(r.label, r.w - 18);
                    ctx.drawTextWithShadow(textRenderer, name, r.x + 4, r.y + 3, on ? 0xFFFFFFFF : 0xFFAAAAAA);
                    if (!r.module.getSettings().isEmpty()) {
                        ctx.drawTextWithShadow(textRenderer, r.module.isExpanded() ? "-" : "+", r.x + r.w - 9, r.y + 3, 0xFFDDDDDD);
                    }
                }
                case SETTING -> {
                    ctx.fill(r.x, r.y, r.x + r.w, r.y + r.h, hover ? 0xEE23233A : 0xEE1A1A28);
                    String name = textRenderer.trimToWidth(r.label, Math.max(8, r.lx0 - r.x - 8));
                    ctx.drawTextWithShadow(textRenderer, name, r.x + 6, r.y + 3, 0xFFCCCCCC);
                    if (!r.setting.isToggle()) {
                        ctx.drawTextWithShadow(textRenderer, "<", r.lx0, r.y + 3, 0xFF9C7CFF);
                        ctx.drawTextWithShadow(textRenderer, ">", r.gx0, r.y + 3, 0xFF9C7CFF);
                    }
                    int col = r.setting.isToggle() ? (r.setting.isOn() ? 0xFF66FF88 : 0xFFFF6666) : 0xFFFFFFFF;
                    ctx.drawTextWithShadow(textRenderer, r.value, r.vx, r.y + 3, col);
                }
            }
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (Row r : buildRows()) {
            if (mx < r.x || mx >= r.x + r.w || my < r.y || my >= r.y + r.h) continue;
            switch (r.kind) {
                case MODULE -> {
                    boolean arrow = mx >= r.x + r.w - 14;
                    if (button == 1 || (button == 0 && arrow)) {
                        if (!r.module.getSettings().isEmpty()) r.module.setExpanded(!r.module.isExpanded());
                    } else if (button == 0) {
                        r.module.toggle();
                    }
                }
                case SETTING -> {
                    NumberSetting s = r.setting;
                    if (s.isToggle()) {
                        s.flip();
                    } else if (mx >= r.gx0 - 3) {
                        s.increase();
                    } else if (mx >= r.lx0 - 3 && mx < r.vx) {
                        s.decrease();
                    } else {
                        // tapping the name / value area: left = increase, right = decrease (handy on touch screens)
                        if (button == 1) s.decrease(); else if (mx > r.vx) s.increase();
                    }
                }
                default -> { }
            }
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
